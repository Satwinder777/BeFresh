package com.example.befresh.view.fragment.explore

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.recyclerview.widget.RecyclerView
import com.example.befresh.R

class ListItemAdapter(var onCheck: onClickChek,var list: ArrayList<CheckModel>):RecyclerView.Adapter<ListItemAdapter.ViewHolder>(){

    var select= false

    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        var checkBoxx:CheckBox = itemView.findViewById(R.id.checkBoxx)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.list_check,parent,false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.apply {
            checkBoxx.isChecked = list[position].select
            checkBoxx.text= list[position].title

            checkBoxx.setOnClickListener {
                if (checkBoxx.isChecked){
                    checkBoxx.isChecked=true
                    list[position].select = true
                }else{
                    checkBoxx.isChecked=false
                    list[position].select=false
                }
                notifyDataSetChanged()
            }
        }
    }

//    http://192.168.1.35:8021

    override fun getItemCount(): Int {
       return list.size
    }

    interface onClickChek{
        fun checkBoxCheck(list:CheckModel)
    }
}