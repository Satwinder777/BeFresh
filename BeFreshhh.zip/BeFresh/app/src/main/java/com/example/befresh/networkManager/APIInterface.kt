package com.gocarhub.networkManager


import com.example.befresh.model.response.GetMenuItemResponse
import com.example.befresh.model.response.SignUpResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*
interface APIInterface {
    companion object {
        const val LOGIN = "login"
        const val SOCIAL_LOGIN = "social-login"
        const val SIGN_UP = "signup"
        const val OTP = "verify-otp"
        const val GET_MENU_ITEM = "get-menu-item"
        const val DELETE_CAR = "delete-car"
        const val FORGOT_PASSWORD = "forgot-password"
        const val PROFILE_DETAILS = "profile-detail"
        const val LOGOUT = "logout"
        const val UPDATE_PROFILE = "update-profile"
        const val CHANGE_PASSWORD = "change-password"
        const val GET_NOTIFICATION = "get-notification"
        const val SEND_REVIEW = "review"
        const val GET_BASIC_DETAILS = "app-basic-details"
        const val CHAT_LIST = "chat-list"
        const val CHAT_DETAIL = "chat-detail"
        const val CAR_CATEGORY = "car-category"
        const val ADD_CAR = "add-car"
        const val GET_ALL_CARS = "get-car"
        const val USER_COUNT = "user-count"
        const val BUYER_REVIEW = "buyer-review"
        const val GET_SUBSCRIPTION = "get-subscription"
        const val SAVE_CARD = "card-save"
        const val GET_CARD = "card-get"
        const val ADD_PAYMENT = "add-payment"
        const val DELETE_CARD = "card-delete"
        const val SELLER_REVIEW = "seller-review"
        const val BUYERS_VIEWS_CARS = "buyer-views-cars"
        const val CAR_FEATURES_LIST = "car-featureslist"
        const val CAR_YEAR = "car-year"
        const val CAR_MAKE = "car-make"
    }

    @Multipart
    @POST(SIGN_UP)
    suspend fun signUp(
        @Part("name") name: RequestBody?,
        @Part("country_code") country_code: RequestBody?,
        @Part("mobile") mobile: RequestBody?,
        @Part("password") password: RequestBody?,
        @Part("user_type") user_type: RequestBody?,
        @Part("device_token") device_token: RequestBody?,
        @Part("device_type") device_type: RequestBody?
    ): SignUpResponse

    @POST(OTP)
    suspend fun otp(@Body map:HashMap<String,Any>): SignUpResponse

    @POST(LOGIN)
    suspend fun login(@Body map:HashMap<String,Any>): SignUpResponse

    @GET(GET_MENU_ITEM)
    suspend fun getMenuItem(): GetMenuItemResponse

}