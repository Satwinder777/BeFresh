package com.example.befresh.view.fragment.explore

data class CheckModel(var select:Boolean,var title:String)
