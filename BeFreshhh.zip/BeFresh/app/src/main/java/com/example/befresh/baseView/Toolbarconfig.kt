package com.example.befresh.baseView

data class ToolbarConfig(var image: Int, var tittle: String, var menuIcon: Int)