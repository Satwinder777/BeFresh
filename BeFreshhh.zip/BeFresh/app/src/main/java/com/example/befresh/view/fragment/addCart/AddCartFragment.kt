package com.example.befresh.view.fragment.addCart

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.interfaces.ItemClickListener
import com.denzcoskun.imageslider.models.SlideModel
import com.example.befresh.R
import com.example.befresh.databinding.FragmentAddCartBinding
import com.example.befresh.baseView.BaseFragment

class AddCartFragment : BaseFragment<FragmentAddCartBinding>() {


    override fun getLayoutResID(): Int {
        return R.layout.fragment_add_cart
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sliderImageSet()
    }

    private fun sliderImageSet() {
        val imageList = ArrayList<SlideModel>()
        imageList.add(
            SlideModel(
                "https://bit.ly/2YoJ77H",
                "",
                ScaleTypes.CENTER_CROP
            )
        )
        imageList.add(
            SlideModel(
                "https://bit.ly/2BteuF2",
                "",
                ScaleTypes.CENTER_CROP
            )
        )
        imageList.add(SlideModel("https://bit.ly/3fLJf72", "", ScaleTypes.CENTER_CROP))

        binding.imageSlider.setImageList(imageList)
        binding.imageSlider.setItemClickListener(object : ItemClickListener {
            override fun onItemSelected(position: Int) {
                // You can listen here
//                binding.imageSlider.startSliding(3000) // with new period
//                binding.imageSlider.startSliding()
//                binding.imageSlider.stopSliding()
            }
        })
    }

    override fun setUpUi(binding: FragmentAddCartBinding) {
    }

}