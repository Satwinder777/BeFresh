package com.example.befresh.view.fragment.explore

import android.os.Bundle
import android.util.Log
import android.view.View
import com.example.befresh.R
import com.example.befresh.baseView.BaseFragment
import com.example.befresh.databinding.FragmentExploreBinding
import com.example.befresh.view.fragment.shop.adapter.ListShowAdapter
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ExploreFragment : BaseFragment<FragmentExploreBinding>(), ListItemAdapter.onClickChek {
    lateinit var adapter: ListItemAdapter
    lateinit var adapterShow: ListShowAdapter

    var list = ArrayList<CheckModel>()

    override fun getLayoutResID(): Int {
        return R.layout.fragment_explore
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        list.add(CheckModel(false, "first"))
        list.add(CheckModel(false, "second"))
        list.add(CheckModel(false, "third"))

        adapter = ListItemAdapter(this, list)
        binding.rvExplore.adapter = adapter

        adapterShow = ListShowAdapter(list)
        binding.rvShow.adapter = adapter
    }

    override fun setUpUi(binding: FragmentExploreBinding) {
    }
    override fun checkBoxCheck(listModel: CheckModel) {
//        if (listModel.select == true) {
//            Log.e("select", listModel.select.toString())
//
//        } else {
//            selectShow = listModel.select
//            binding.checSho.isChecked = listModel.select
//            Log.e("select un", listModel.select.toString())
//        https://api.postman.com/collections/7836352-b8d02228-fb6f-4be4-bbda-590c386c6c94?access_key=PMAT-01GKSJEKK1QNCG5MQNJTH4Y9S7
//        https://befresh.zaibainfotech.com/
//        }
    }


}